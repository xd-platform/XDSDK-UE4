//
//  XDGAlertViewForAnti.h
//  TDSGlobalSDKCommonKit
//
//  Created by jessy on 2021/12/2.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^XDGAlertLeftCallback)(void);
typedef void(^XDGAlertRightCallback)(void);
typedef void(^XDGAlertChangeAccountCallback)(void);

@interface XDGAlertViewForAnti : UIView

@property (nonatomic) XDGAlertLeftCallback rightCallback;
@property (nonatomic) XDGAlertRightCallback leftCallback;
@property (nonatomic,copy)XDGAlertChangeAccountCallback changeBtnCallBack;
// 点击背景取消，默认否
@property (nonatomic) BOOL touchBgDismiss;

+ (XDGAlertViewForAnti *)createAlertView:(NSString *)title
                                content:(NSString *)content
                            rightText:(NSString *)rightText
                             leftText:(NSString * _Nullable)leftText;

- (void)showInView:(UIView *)targetView;
- (void)dismiss;

@property (nonatomic,copy) NSString *userID;

@end

NS_ASSUME_NONNULL_END
