//
//  TDSImageTool.h
//  TDSSDK
//
//  Created by JiangJiahao on 2020/9/28.
//  Copyright © 2020 JiangJiahao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


NS_ASSUME_NONNULL_BEGIN

@interface TDSGlobalImageTool : NSObject
+ (UIImage *)scaleToSize:(UIImage *)img size:(CGSize)size;
@end

NS_ASSUME_NONNULL_END
