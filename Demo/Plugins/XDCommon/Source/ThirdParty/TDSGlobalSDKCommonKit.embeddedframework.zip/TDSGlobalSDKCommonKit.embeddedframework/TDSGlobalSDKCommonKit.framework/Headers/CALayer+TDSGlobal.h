//
//  CALayer+TDSGlobal.h
//  XDCommonSDK
//
//  Created by JiangJiahao on 2020/11/25.
//

#import <QuartzCore/QuartzCore.h>

NS_ASSUME_NONNULL_BEGIN

@interface CALayer (TDSGlobal)

- (void)showWithAnimate:(nullable void (^)(void))animate completion:(nullable void (^)(void))completion;
@end

NS_ASSUME_NONNULL_END
