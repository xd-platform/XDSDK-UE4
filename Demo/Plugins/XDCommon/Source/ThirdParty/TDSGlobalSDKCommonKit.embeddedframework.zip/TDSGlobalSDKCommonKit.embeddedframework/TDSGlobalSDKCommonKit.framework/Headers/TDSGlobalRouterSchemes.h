//
//  TDSGlobalRouterSchemes.h
//  TDSGlobalSDKCommonKit
//
//  Created by JiangJiahao on 2021/3/1.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
typedef NSString * const TDSGlobalRouterScheme NS_TYPED_EXTENSIBLE_ENUM;

/** 支付 */
FOUNDATION_EXPORT TDSGlobalRouterScheme TDSGLOBAL_STORE_INIT_SCHEME;
FOUNDATION_EXPORT TDSGlobalRouterScheme TDSGLOBAL_STORE_PAY_SCHEME;

/** 事件 */
FOUNDATION_EXPORT TDSGlobalRouterScheme TDSGLOBAL_TRACK_PAY_SUCCESS_SCHEME;

@interface TDSGlobalRouterSchemes : NSObject

@end

NS_ASSUME_NONNULL_END
