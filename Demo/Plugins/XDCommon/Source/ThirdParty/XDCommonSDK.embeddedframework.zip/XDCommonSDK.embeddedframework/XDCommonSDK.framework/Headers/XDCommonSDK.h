



#import <Foundation/Foundation.h>

#import <XDCommonSDK/XDSDK.h>
#import <XDCommonSDK/XDGGameDataManager.h>
#import <XDCommonSDK/XDGEntryType.h>
#import <XDCommonSDK/XDGGameBindEntry.h>
#import <XDCommonSDK/XDGMainButton.h>
#import <XDCommonSDK/XDGTrackerManager.h>
#import <XDCommonSDK/XDGReportManager.h>
#import <XDCommonSDK/XDGMessageManager.h>
#import <XDCommonSDK/XDGShare.h>
#import <XDCommonSDK/XDUser.h>
#import <XDCommonSDK/XDGUserDataManager.h>
#import <XDCommonSDK/XDAccessToken.h>
#import <XDCommonSDK/XDGGlobalGame.h>
#import <XDCommonSDK/XDGTapTapInfo.h>
#import <XDCommonSDK/XDGGlobalConfigManager.h>
#import <XDCommonSDK/XDwxdelegate.h>
#import <TDSGlobalSDKCommonKit/UILabel+XDLabTools.h>

#define XDGSDK_VERSION @"6.2.0"
#define TDSGLOBALSDK_NAME @"XD-CN-SDK"


